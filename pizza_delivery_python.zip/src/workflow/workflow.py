from typing import Any, Dict, List, Optional, Union, Tuple
import logging
from datetime import datetime, timedelta

# Import dapr workflow modules
from dapr.ext.workflow import DaprWorkflowContext, WorkflowActivityContext, WorkflowRuntime
from dapr.ext.workflow import when_any, when_all

# Import activities from separate module
from workflow.activities import *

# Import workflow runtime
from workflow.runtime import workflow_runtime as wfr
from workflow.replay_safe_logger import ReplaySafeLogger

# Import workflow data model
from workflow.models import WorkflowData

logging.basicConfig(level=logging.INFO)
base_logger = logging.getLogger(__name__)

store_name = "statestore"

###############################################################################
# IMPORTANT: Keep Workflow Code Deterministic
###############################################################################
# 1. Don't use random.random(), time.time(), uuid.uuid4() directly in workflows
#    Instead use ctx.current_utc_datetime() for current time
# 2. Don't make direct I/O or service calls - use activities instead
#    Example: data = yield ctx.call_activity('MakeHttpCall', 'https://example.com/api/data')
# 3. Don't use mutable global state or global variables
# 4. Use the workflow context for all external interactions
# 5. Keep workflow functions deterministic - they may be replayed multiple times
###############################################################################

###############################################################################
# Name: PizzaOrderWorkflow
# Description: Handles the process of ordering, preparing, and delivering pizza to customers.
###############################################################################

@wfr.workflow(name="pizza_order_workflow")
def pizza_order_workflow(ctx: DaprWorkflowContext, input_data: Any) -> Any:
    """
    Handles the process of ordering, preparing, and delivering pizza to customers.

    Args:
        ctx: The workflow context provided by Dapr
        input_data: Data passed to the workflow

    Returns:
        The workflow result
    """
    logger = ReplaySafeLogger(ctx, base_logger)
    logger.info(f"[Workflow] Starting workflow: {ctx.instance_id}")

    # Convert input data to WorkflowData object
    data = WorkflowData.from_dict(input_data)

    logger.info("[Workflow] Executing activity: Processes the customer's pizza order.")
    activity_result = yield ctx.call_activity(pizza_store_activity_activity, input=data.get_activity_request_data())
    data.add_activity_response('pizza_store_activity', activity_result)

    logger.info("[Workflow] Executing activity: Prepares the pizza in the kitchen.")
    activity_result = yield ctx.call_activity(pizza_kitchen_activity_activity, input=data.get_activity_request_data())
    data.add_activity_response('pizza_kitchen_activity', activity_result)

    logger.info("[Workflow] Waiting for event (label pizza_quality_verified): Waits for manager to verify pizza quality.")
    event_data = yield ctx.wait_for_external_event("pizza_quality_verified")

    logger.info("[Workflow] Received pizza_quality_verified event")
    data.add_event_response("pizza_quality_verified", ctx.current_utc_datetime, event_data)

    logger.info("[Workflow] Executing activity: Delivers the pizza to the customer.")
    activity_result = yield ctx.call_activity(pizza_delivery_activity_activity, input=data.get_activity_request_data())
    data.add_activity_response('pizza_delivery_activity', activity_result)

    logger.info("[Workflow] Workflow reached end: End of pizza delivery process")
    # Return the final workflow data
    return data
