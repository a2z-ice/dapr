from typing import Any, Dict, List, Optional, Union, Tuple
import logging
from datetime import datetime, timedelta

# Import dapr workflow modules
from dapr.ext.workflow import DaprWorkflowContext, WorkflowActivityContext, WorkflowRuntime
from dapr.ext.workflow import when_any, when_all

# Import activities from separate module
from workflow.activities import *

# Import workflow runtime
from workflow.runtime import workflow_runtime as wfr
from workflow.replay_safe_logger import ReplaySafeLogger

# Import workflow data model
from workflow.models import WorkflowData

logging.basicConfig(level=logging.INFO)
base_logger = logging.getLogger(__name__)

store_name = "statestore"

###############################################################################
# IMPORTANT: Keep Workflow Code Deterministic
###############################################################################
# 1. Don't use random.random(), time.time(), uuid.uuid4() directly in workflows
#    Instead use ctx.current_utc_datetime() for current time
# 2. Don't make direct I/O or service calls - use activities instead
#    Example: data = yield ctx.call_activity('MakeHttpCall', 'https://example.com/api/data')
# 3. Don't use mutable global state or global variables
# 4. Use the workflow context for all external interactions
# 5. Keep workflow functions deterministic - they may be replayed multiple times
###############################################################################

###############################################################################
# Name: OrderProcessingWorkflow
# Description: Handles the inventory verification, approval, payment processing, and notification for orders.
###############################################################################

@wfr.workflow(name="order_processing_workflow")
def order_processing_workflow(ctx: DaprWorkflowContext, input_data: Any) -> Any:
    """
    Handles the inventory verification, approval, payment processing, and notification for orders.

    Args:
        ctx: The workflow context provided by Dapr
        input_data: Data passed to the workflow

    Returns:
        The workflow result
    """
    logger = ReplaySafeLogger(ctx, base_logger)
    logger.info(f"[Workflow] Starting workflow: {ctx.instance_id}")

    # Convert input data to WorkflowData object
    data = WorkflowData.from_dict(input_data)

    logger.info("[Workflow] Executing activity: Sends initial notification.")
    activity_result = yield ctx.call_activity(notify_activity_1_activity, input=data.get_activity_request_data())
    data.add_activity_response('notify_activity_1', activity_result)

    logger.info("[Workflow] Executing activity: Verifies if inventory is sufficient for the order.")
    activity_result = yield ctx.call_activity(verify_inventory_activity_activity, input=data.get_activity_request_data())
    data.add_activity_response('verify_inventory_activity', activity_result)

    logger.info(f"[Workflow] Evaluating condition: Checks if inventory is sufficient. (label: inventory_sufficient)")

    if data.get_bool('inventory_sufficient'):
        logger.info("[Workflow] Selected condition: 'Yes'")

        logger.info(f"[Workflow] Evaluating condition: Checks if order cost exceeds $5000. (label: cost_exceeds_threshold)")

        if data.get_bool('cost_exceeds_threshold'):
            logger.info("[Workflow] Selected condition: 'Yes'")

            logger.info("[Workflow] Executing activity: Requests approval for orders over $5000.")
            activity_result = yield ctx.call_activity(request_approval_activity_activity, input=data.get_activity_request_data())
            data.add_activity_response('request_approval_activity', activity_result)

            logger.info("[Workflow] Waiting for event (label approval_decision_received): Waits for approval decision from approver.")
            event_data = yield ctx.wait_for_external_event("approval_decision_received")

            logger.info("[Workflow] Received approval_decision_received event")
            data.add_event_response("approval_decision_received", ctx.current_utc_datetime, event_data)

            logger.info(f"[Workflow] Evaluating condition: Determines action based on approval decision. (label: order_approved)")

            if data.get_bool('order_approved'):
                logger.info("[Workflow] Selected condition: 'Approved'")

                return (yield from process_process_payment_activity(ctx, data))
            else:
                logger.info("[Workflow] Selected condition: 'Not approved' for 'Determines action based on approval decision.'")

                logger.info("[Workflow] Executing activity: Sends notification for non-approved orders.")
                activity_result = yield ctx.call_activity(notify_activity_4_activity, input=data.get_activity_request_data())
                data.add_activity_response('notify_activity_4', activity_result)

                return process_end_node(ctx, data)
        else:
            logger.info("[Workflow] Selected condition: 'No' for 'Checks if order cost exceeds $5000.'")

            return (yield from process_process_payment_activity(ctx, data))
    else:
        logger.info("[Workflow] Selected condition: 'No' for 'Checks if inventory is sufficient.'")

        logger.info("[Workflow] Executing activity: Sends notification for insufficient inventory.")
        activity_result = yield ctx.call_activity(notify_activity_2_activity, input=data.get_activity_request_data())
        data.add_activity_response('notify_activity_2', activity_result)

        return process_end_node(ctx, data)


def process_process_payment_activity(ctx: DaprWorkflowContext, data: WorkflowData) -> Any:
    """
    Args:
        ctx: The workflow context
        data: The workflow data object

    Returns:
        The updated workflow data
    """
    logger = ReplaySafeLogger(ctx, base_logger)
    logger.info("[Workflow] Executing activity: Processes payment for the order.")
    activity_result = yield ctx.call_activity(process_payment_activity_activity, input=data.get_activity_request_data())
    data.add_activity_response('process_payment_activity', activity_result)

    logger.info("[Workflow] Executing activity: Updates inventory after successful payment.")
    activity_result = yield ctx.call_activity(update_inventory_activity_activity, input=data.get_activity_request_data())
    data.add_activity_response('update_inventory_activity', activity_result)

    logger.info("[Workflow] Executing activity: Sends notification after successful order processing.")
    activity_result = yield ctx.call_activity(notify_activity_3_activity, input=data.get_activity_request_data())
    data.add_activity_response('notify_activity_3', activity_result)

    return process_end_node(ctx, data)


def process_end_node(ctx: DaprWorkflowContext, data: WorkflowData) -> Any:
    """
    Args:
        ctx: The workflow context
        data: The workflow data object

    Returns:
        The updated workflow data
    """
    logger = ReplaySafeLogger(ctx, base_logger)
    logger.info("[Workflow] Workflow reached end: End")
    # Return the final workflow data
    return data
