from typing import Any, Dict, List, Optional, Union, Tuple
import logging
from datetime import datetime, timedelta

# Import dapr workflow modules
from dapr.ext.workflow import DaprWorkflowContext, WorkflowActivityContext, WorkflowRuntime
from dapr.ext.workflow import when_any, when_all

# Import activities from separate module
from workflow.activities import *

# Import workflow runtime
from workflow.runtime import workflow_runtime as wfr
from workflow.replay_safe_logger import ReplaySafeLogger

# Import workflow data model
from workflow.models import WorkflowData

logging.basicConfig(level=logging.INFO)
base_logger = logging.getLogger(__name__)

store_name = "statestore"

###############################################################################
# IMPORTANT: Keep Workflow Code Deterministic
###############################################################################
# 1. Don't use random.random(), time.time(), uuid.uuid4() directly in workflows
#    Instead use ctx.current_utc_datetime() for current time
# 2. Don't make direct I/O or service calls - use activities instead
#    Example: data = yield ctx.call_activity('MakeHttpCall', 'https://example.com/api/data')
# 3. Don't use mutable global state or global variables
# 4. Use the workflow context for all external interactions
# 5. Keep workflow functions deterministic - they may be replayed multiple times
###############################################################################

###############################################################################
# Name: OrderApprovalWorkflow
# Description: Handles the order processing and shipping after approval.
###############################################################################

@wfr.workflow(name="order_approval_workflow")
def order_approval_workflow(ctx: DaprWorkflowContext, input_data: Any) -> Any:
    """
    Handles the order processing and shipping after approval.

    Args:
        ctx: The workflow context provided by Dapr
        input_data: Data passed to the workflow

    Returns:
        The workflow result
    """
    logger = ReplaySafeLogger(ctx, base_logger)
    logger.info(f"[Workflow] Starting workflow: {ctx.instance_id}")

    # Convert input data to WorkflowData object
    data = WorkflowData.from_dict(input_data)

    logger.info("[Workflow] Executing activity: Processes the customer order.")
    activity_result = yield ctx.call_activity(process_order_activity, input=data.get_activity_request_data())
    data.add_activity_response('process_order', activity_result)

    logger.info("[Workflow] Waiting for event (label order_approval_received): Waits for order approval message.")
    event_data = yield ctx.wait_for_external_event("order_approval_received")

    logger.info("[Workflow] Received order_approval_received event")
    data.add_event_response("order_approval_received", ctx.current_utc_datetime, event_data)

    logger.info("[Workflow] Executing activity: Ships the approved order to the customer.")
    activity_result = yield ctx.call_activity(ship_order_activity, input=data.get_activity_request_data())
    data.add_activity_response('ship_order', activity_result)

    logger.info("[Workflow] Workflow reached end: End of order process")
    # Return the final workflow data
    return data
