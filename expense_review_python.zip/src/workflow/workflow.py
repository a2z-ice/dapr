from typing import Any, Dict, List, Optional, Union, Tuple
import logging
from datetime import datetime, timedelta

# Import dapr workflow modules
from dapr.ext.workflow import DaprWorkflowContext, WorkflowActivityContext, WorkflowRuntime
from dapr.ext.workflow import when_any, when_all

# Import activities from separate module
from workflow.activities import *

# Import workflow runtime
from workflow.runtime import workflow_runtime as wfr
from workflow.replay_safe_logger import ReplaySafeLogger

# Import workflow data model
from workflow.models import WorkflowData

logging.basicConfig(level=logging.INFO)
base_logger = logging.getLogger(__name__)

store_name = "statestore"

###############################################################################
# IMPORTANT: Keep Workflow Code Deterministic
###############################################################################
# 1. Don't use random.random(), time.time(), uuid.uuid4() directly in workflows
#    Instead use ctx.current_utc_datetime() for current time
# 2. Don't make direct I/O or service calls - use activities instead
#    Example: data = yield ctx.call_activity('MakeHttpCall', 'https://example.com/api/data')
# 3. Don't use mutable global state or global variables
# 4. Use the workflow context for all external interactions
# 5. Keep workflow functions deterministic - they may be replayed multiple times
###############################################################################

###############################################################################
# Name: ExpenseReviewProcess
# Description: Handles the review and processing of expense reports.
###############################################################################

@wfr.workflow(name="expense_review_process")
def expense_review_process(ctx: DaprWorkflowContext, input_data: Any) -> Any:
    """
    Handles the review and processing of expense reports.

    Args:
        ctx: The workflow context provided by Dapr
        input_data: Data passed to the workflow

    Returns:
        The workflow result
    """
    logger = ReplaySafeLogger(ctx, base_logger)
    logger.info(f"[Workflow] Starting workflow: {ctx.instance_id}")

    # Convert input data to WorkflowData object
    data = WorkflowData.from_dict(input_data)

    logger.info("[Workflow] Executing activity: Review Expense Report")
    activity_result = yield ctx.call_activity(review_expense_report_activity, input=data.get_activity_request_data())
    data.add_activity_response('review_expense_report', activity_result)

    logger.info(f"[Workflow] Evaluating condition: Expense Approved? (label: expense_approved)")

    if data.get_bool('expense_approved'):
        logger.info("[Workflow] Selected condition: 'Yes'")

        logger.info("[Workflow] Executing activity: Process Reimbursement")
        activity_result = yield ctx.call_activity(process_reimbursement_activity, input=data.get_activity_request_data())
        data.add_activity_response('process_reimbursement', activity_result)

        logger.info("[Workflow] Workflow reached end: Expense Reimbursed")
        # Return the final workflow data
        return data
    else:
        logger.info("[Workflow] Selected condition: 'No' for 'Expense Approved?'")

        logger.info("[Workflow] Workflow reached end: Expense Rejected")
        # Return the final workflow data
        return data
